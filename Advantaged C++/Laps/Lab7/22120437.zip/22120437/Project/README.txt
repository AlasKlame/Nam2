Thầy yêu cầu làm mỗi bài 1 project, nhưng vì em đang ôn thi nên em sẽ gộp 5 bài thành 1 project mà vẫn đáp ứng đủ yêu cầu của thầy   
Em cảm ơn thầy đã đọc