Chương trình được viết theo yêu cầu
Thông tin được nhập, xuất vào từ file INPUT.txt và file OUTPUT.txt
Việc tính toán giá tiền theo yêu cầu 2 từ đề bài sẽ được thực hiện trên cửa số console